//
//  CardScan.h
//  CardScan
//
//  Created by Sam King on 12/13/20.
//

#import <Foundation/Foundation.h>

//! Project version number for CardScan.
FOUNDATION_EXPORT double CardScanVersionNumber;

//! Project version string for CardScan.
FOUNDATION_EXPORT const unsigned char CardScanVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CardScan/PublicHeader.h>


